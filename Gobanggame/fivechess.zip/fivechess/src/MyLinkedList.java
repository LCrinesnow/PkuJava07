﻿
class MyLinkedList{
int length=0;
Node firstNode;

public int size(){
   return length;
}

//public void insNewSecNode(int x,int y,char direction,int degree,int flag){
//   if(length==0) return;
//   Node newNode=new Node();
//   newNode.x=x;
//   newNode.y=y;
//   newNode.direction=direction;
//   newNode.degree=degree;
//   newNode.flag=flag;
//   newNode.next=firstNode.next;
//   firstNode.next=newNode;
//   length++;
//}

public Node BestSearch(int role){
   Node N;
   Node best;
   N=firstNode;
   best=firstNode;
   while(N!=null){
    if(best.degree>N.degree){
     best=N;
    }
    else if(best.degree==N.degree){
    	if(N.flag==role) 
    		best=N;
    }
    N=N.next;
   }
   return best;
}

//public void deleteNode(int x,int y){
//	Node N;
//	N=firstNode;
//	if(N.x==x&&N.y==y) N.next=firstNode;
//	while(N.next.next!=null){
//		if(N.next.x==x&&N.next.y==y){
//			N.next=N.next.next;
//			break;
//		}
//		else{
//			N=N.next;
//		}
//	}
//	
//}

public void insNewLastNode(int x,int y,char direction,int degree,String flag){
   Node N=new Node();
   N.x=x;
   N.y=y;
   N.direction=direction;
   N.degree=degree;
   N.flag=flag.equals(Chessman.BLACK.getChessman()) ? 1: 0;
   N.next=null;
   if(firstNode==null){
    firstNode=N;
   }
   else{
    Node P=firstNode;
    while(P.next!=null){
     P=P.next;
    }
    P.next=N;
   }
   length++;
}

public void print(){
	   Node N;
	   System.out.print("(");
	   N=firstNode;
	   while(N!=null){
	    System.out.printf("%d,(%d,%d)",N.degree,N.x+1,N.y+1);
	    N=N.next;
	    if(N!=null){
	     System.out.print(",");
	    }
	   }
	   System.out.println(")");
	}
}//end class LinkedList