﻿
public class Node {
	int x;
	int y;
	char direction;	//方向
	int degree;		//等级
	int flag;		//谁的棋子
	Node next;
}
