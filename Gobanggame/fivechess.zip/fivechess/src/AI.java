﻿
import java.util.LinkedList;
import java.util.Queue;
import java.util.Random;

//1.五子：某一方形成五个相同颜色的棋子相连
//2.活四：形成四子相连，并且两端是都没有子的
//3.冲四：形成四子相连，并且有一端是有对方棋子或者是墙壁，而另一端是没有子的
//4.活三：形成三子相连，并且两端是都没有子的
//5.死三：形成三子相连，并且有一端是有对方棋子或者是墙壁，而另一端是没有子的
//6.活二：形成两子相连，并且两端是都没有子的
//7.死二：形成两子相连，并且有一端是有对方棋子或者是墙壁，而另一端是没有子的
//8.活单：一颗子，另一端两端没有子
//9.死单:一颗子，一端有子或墙壁，一端无子

public class AI {
	private MyLinkedList keyPoint = new MyLinkedList();		//存放所有关键落子点
	private String[][] chessboard ; 
	private static final int AIflag = 0 ;
	private static final int Userflag = 1 ;
	private int kind(int x,int y,int addX,int addY,int role){	//区分棋形种类
		x+=addX;			//X方向增加值
		y+=addY;			//Y方向增加值
		int kind=10;		//等级
		while(true){
		 if(x==15||y==15||x==-1||y==-1){
			kind++;
			break;
		 }
		 else if(chessboard[x][y].equals(Chessman.WHITE.getChessman())&&role==0) kind-=2;	//如果此处为AI的棋子而且正在计算AI的落子等级，则升高两级
		 else if(chessboard[x][y].equals(Chessman.BLACK.getChessman())&&role==0){		//如果此处为用户的棋子而且正在计算AI的落子等级，则降低一级
			kind++;			//等级降低一级
			break;			//退出循环
		 }
		 else if(chessboard[x][y].equals(Chessman.BLACK.getChessman())&&role==1) kind-=2;	//如果此处为用户的棋子而且正在计算用户的落子等级，则升高两级
		 else if(chessboard[x][y].equals(Chessman.WHITE.getChessman())&&role==1){			//如果此处为AI的棋子而且正在计算用户的落子等级，等级降低一级
				kind++;			//等级降低一级
				break;			//退出循环
		 }
		 else if(chessboard[x][y].equals("+")){			//如果另一端无子
			if((x+addX)>=0&&(y+addY)>=0&&(x+addX)<=14&&(y+addY)<=14&&chessboard[x+addX][y+addY].equals(Chessman.WHITE.getChessman())&&role==0)
				kind-=2;
			else if((x+addX)>=0&&(y+addY)>=0&&(x+addX)<=14&&(y+addY)<=14&&chessboard[x+addX][y+addY].equals(Chessman.BLACK.getChessman())&&role==1)
				kind-=2;
			break;
		 }
		 x+=addX;			//X方向增加值
		 y+=addY;			//Y方向增加值
		}
		return kind;
	}
	
	private int countDegree(int x,int y,char direction,String str_role){	//评价可落子点的等级
		int degree=10;
		int role = str_role.equals(Chessman.BLACK.getChessman()) ? 1 : 0 ;
		switch(direction){
		 case 'a':  if(degree>=kind(x,y,0,1,role))		//向右
						degree=kind(x,y,0,1,role);
		 			break;
		 case 'b':	if(degree>=kind(x,y,1,1,role))		//向右下
						degree=kind(x,y,1,1,role);
					break;
		 case 'c':	if(degree>=kind(x,y,1,0,role))		//向下
						degree=kind(x,y,1,0,role);
					break;
		 case 'd':  if(degree>=kind(x,y,1,-1,role))		//向左下
			 			degree=kind(x,y,1,-1,role);
		 			break;
		 case 'e':  if(degree>=kind(x,y,0,-1,role))		//向左
	 					degree=kind(x,y,0,-1,role);
					break;
		 case 'f':  if(degree>=kind(x,y,-1,-1,role))		//向左上
	 					degree=kind(x,y,-1,-1,role);
					break;
		 case 'g':  if(degree>=kind(x,y,-1,0,role))		//向上
	 					degree=kind(x,y,-1,0,role);
					break;
		 case 'h':  if(degree>=kind(x,y,-1,1,role))		//向右上
						degree=kind(x,y,-1,1,role);
					break;
		 default: 	break;
		}
		return degree;
	}
	
	private void searchKeyPoint(){
		for(int i=0;i<15;i++){
		 for(int j=0;j<15;j++){
			if(!chessboard[i][j].equals("+")){			//搜索到一处有棋子
				if(j>=1&&chessboard[i][j-1].equals("+")){
					keyPoint.insNewLastNode(i, j-1, 'a', countDegree(i,j-1,'a',chessboard[i][j]), chessboard[i][j]);
				}
				if(i>=1&&j>=1&&chessboard[i-1][j-1].equals("+")){
					keyPoint.insNewLastNode(i-1, j-1, 'b', countDegree(i-1,j-1,'b',chessboard[i][j]), chessboard[i][j]);
				}
				if(i>=1&&chessboard[i-1][j].equals("+")){
					keyPoint.insNewLastNode(i-1, j, 'c', countDegree(i-1,j,'c',chessboard[i][j]), chessboard[i][j]);
				}
				if(i>=1&&j<=13&&chessboard[i-1][j+1].equals("+")){
					keyPoint.insNewLastNode(i-1, j+1, 'd', countDegree(i-1,j+1,'d',chessboard[i][j]), chessboard[i][j]);
				}
				if(j<=13&&chessboard[i][j+1].equals("+")){
					keyPoint.insNewLastNode(i, j+1, 'e', countDegree(i,j+1,'e',chessboard[i][j]), chessboard[i][j]);
				}
				if(i<=13&&j<=13&&chessboard[i+1][j+1].equals("+")){
					keyPoint.insNewLastNode(i+1, j+1, 'f', countDegree(i+1,j+1,'f',chessboard[i][j]), chessboard[i][j]);
				}
				if(i<=13&&chessboard[i+1][j].equals("+")){
					keyPoint.insNewLastNode(i+1, j, 'g', countDegree(i+1,j,'g',chessboard[i][j]), chessboard[i][j]);
				}
				if(j>=1&&i<=13&&chessboard[i+1][j-1].equals("+")){
					keyPoint.insNewLastNode(i+1, j-1, 'h', countDegree(i+1,j-1,'h',chessboard[i][j]), chessboard[i][j]);
				}
			}
		 }
		}
	}
	
	public int[] choosePoint(){			//AI落子
		int x = 0;
		int y = 0;
		if(keyPoint.length==0){			//如果没有任何合适位置——链表中没有可选位置
			while(true){
			 Random r = new Random();		//产生随机数
			 int n1 = r.nextInt(10);		
			 int n2 = r.nextInt(10);
			 n1 = Math.abs(r.nextInt() % 10);   //获取10以内整数
			 n2 = Math.abs(r.nextInt() % 10);
			 
			 if(chessboard[n1][n2].equals("+")){		//如果这个位置没有棋子
				//mf.bt[n1][n2].setColor(AIflag);
				//chessboard[n1][n2]=Chessman.WHITE.getChessman();
				 int[] result = {n1, n2};
				 return result ;
				//mf.bt[n1][n2].property=AIflag;	//标记已有棋子
				// System.out.printf("%d,%d\n",n1+1,n2+1);
				//break;
			 }
			}
		}
		else{
		 x=keyPoint.BestSearch(AIflag).x;
		 y=keyPoint.BestSearch(AIflag).y;
		// mf.bt[x][y].setColor(AIflag);
		 chessboard[x][y]=Chessman.WHITE.getChessman();;
		// mf.bt[x][y].property=AIflag;
		 System.out.printf("%d,%d\n",x+1,y+1);
		}
		int[] result = {x, y};
		 return result ;
		//mf.win(x,y,mf.AIflag);
	}
	
	public AI(Chessboard chessboard){
		this.chessboard = chessboard.getBoard() ;
		searchKeyPoint();
		//choosePoint();
		//keyPoint.print();
	}
}
